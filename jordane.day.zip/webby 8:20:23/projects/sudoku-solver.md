---
name: sudoku-solver
number: 01
subtitle: a java project that recursively solves a set of given sudoku puzzles
date: 12/06/22
---
<a href = "https://github.com/jordaeday/sudoku-solver"> github link</a>
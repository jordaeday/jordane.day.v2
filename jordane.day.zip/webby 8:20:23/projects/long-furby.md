---
name: long-furby
number: 02
subtitle: a hackathon project resulting in an internet-inspired long furby
date: 11/13/22
---
<a href = "https://devpost.com/software/long-furby"> devpost link</a>